# QuickBite

Root project structure, per the required layout — one root folder containing
`frontend/` and `backend/`, each self-contained:

```
quickbite/
├── backend/                    # FastAPI (Python)
│   ├── app/
│   │   ├── __init__.py
│   │   └── main.py             # all REQ-1..REQ-42 endpoints/functions
│   └── requirements.txt
└── frontend/                   # React
    ├── package.json
    ├── public/
    │   └── index.html
    └── src/
        ├── index.js
        ├── App.jsx              # routing: /signup -> /restaurants -> /restaurants/:id -> /checkout -> /order-confirmation
        ├── tokens.css           # QuickBite design tokens (SRS §3.1.2-3.1.4), named tokens only
        ├── api/
        │   └── client.js        # fetch wrapper, base URL from REACT_APP_API_BASE_URL
        └── pages/
            ├── Signup.jsx
            ├── Restaurants.jsx
            ├── RestaurantMenu.jsx
            ├── Checkout.jsx
            └── OrderConfirmation.jsx
```

## Tech stack

- **Backend:** FastAPI (Python) — see `backend/README` info below
- **Frontend:** React (Create React App conventions, react-router-dom for routing)

## Running locally

**Backend:**
```bash
cd backend
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

**Frontend:**
```bash
cd frontend
npm install
REACT_APP_API_BASE_URL=http://localhost:8000 npm start
```

## For the Testing Agent pipeline

`tech_stack` metadata to pass in:
```json
{
  "runtime": "python",
  "framework": "fastapi",
  "db": "in-memory",
  "frontend": {"present": true, "framework": "react", "dev_port": 3000}
}
```

**Two deliberate bugs are in `backend/app/main.py`** (marked `# BUG:`), included on
purpose so running `test_cases.json` against this code produces a genuine `FAIL`
verdict rather than an all-green run:
1. **REQ-4** — account locks on the 6th failed login, not the 5th (off-by-one).
2. **REQ-16** — an order exactly at the minimum order value is incorrectly rejected.

**One real E2E flow is wired end-to-end** in the frontend, matching a `type:
"e2e_flow"` test case: signup (`/signup`) → redirects to `/restaurants`, which
renders an `id="welcome-msg"` element containing "Welcome" — this is what a
Playwright spec like the one in the plan's `codegen/e2e_playwright.py` would
actually click through and assert against.
