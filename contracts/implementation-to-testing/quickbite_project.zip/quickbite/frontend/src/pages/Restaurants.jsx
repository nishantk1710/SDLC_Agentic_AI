import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api/client";

export default function Restaurants() {
  const [restaurants, setRestaurants] = useState([]);

  useEffect(() => {
    api.listRestaurants().then(setRestaurants).catch(() => setRestaurants([]));
  }, []);

  return (
    <div style={{ maxWidth: 700, margin: "0 auto", padding: "24px" }}>
      <h1 id="welcome-msg">Welcome</h1>
      <p>Restaurants delivering to you:</p>
      {restaurants.map((r) => (
        <Link
          key={r.id}
          to={`/restaurants/${r.id}`}
          className="card"
          style={{ display: "block", textDecoration: "none", color: "inherit" }}
        >
          <h3>{r.name}</h3>
          <p>
            {r.cuisine} · ⭐ {r.average_rating} · {r.estimated_delivery_time} min ·
            ₹{r.delivery_fee} delivery
          </p>
        </Link>
      ))}
    </div>
  );
}
