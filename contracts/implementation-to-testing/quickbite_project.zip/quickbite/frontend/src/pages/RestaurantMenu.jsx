import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { api } from "../api/client";

export default function RestaurantMenu() {
  const { id } = useParams();
  const [restaurant, setRestaurant] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    api.getRestaurant(id).then(setRestaurant).catch(() => setRestaurant(null));
  }, [id]);

  async function handleAddAndCheckout() {
    await api.addToCart({ menu_item_id: "item-1", quantity: 1 });
    navigate("/checkout");
  }

  if (!restaurant) return <p style={{ padding: 24 }}>Loading…</p>;

  return (
    <div style={{ maxWidth: 700, margin: "0 auto", padding: "24px" }}>
      <h2>{restaurant.name}</h2>
      <div className="card">
        <h3>Butter Chicken — ₹250</h3>
        <button id="add-to-cart" className="btn-primary" onClick={handleAddAndCheckout}>
          Add to Cart &amp; Checkout
        </button>
      </div>
    </div>
  );
}
