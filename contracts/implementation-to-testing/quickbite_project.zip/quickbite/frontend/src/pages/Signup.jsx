import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../api/client";

export default function Signup() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    setError(null);
    try {
      await api.register({ email, password });
      navigate("/restaurants");
    } catch (err) {
      setError(err.body?.detail || "Registration failed");
    }
  }

  return (
    <div className="card" style={{ maxWidth: 400, margin: "48px auto" }}>
      <h2>Create your account</h2>
      <form onSubmit={handleSubmit}>
        <input
          id="email"
          type="email"
          placeholder="Email address"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          id="password"
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        {error && <div className="field-error">{error}</div>}
        <button id="submit" className="btn-primary" type="submit">
          Sign Up
        </button>
      </form>
    </div>
  );
}
