import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../api/client";

export default function Checkout() {
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  async function handleConfirm() {
    setError(null);
    try {
      await api.checkout({ subtotal: 250, restaurant_minimum_order_value: 200 });
      await api.confirmOrder({ prepaid: true });
      navigate("/order-confirmation");
    } catch (err) {
      setError(err.body?.detail || "Checkout failed");
    }
  }

  return (
    <div className="card" style={{ maxWidth: 400, margin: "48px auto" }}>
      <h2>Checkout</h2>
      <p>Subtotal: ₹250</p>
      {error && <div className="field-error">{error}</div>}
      <button id="confirm-order" className="btn-primary" onClick={handleConfirm}>
        Confirm Order
      </button>
    </div>
  );
}
