export default function OrderConfirmation() {
  return (
    <div className="card" style={{ maxWidth: 400, margin: "48px auto", textAlign: "center" }}>
      <h2 id="order-confirmed-msg">Order Confirmed!</h2>
      <p>Your order has been sent to the restaurant.</p>
    </div>
  );
}
