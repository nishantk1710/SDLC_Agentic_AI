import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import "./tokens.css";
import Signup from "./pages/Signup";
import Restaurants from "./pages/Restaurants";
import RestaurantMenu from "./pages/RestaurantMenu";
import Checkout from "./pages/Checkout";
import OrderConfirmation from "./pages/OrderConfirmation";

function TopNav() {
  return (
    <nav className="top-nav">
      <strong style={{ fontFamily: "var(--font-heading-family)", color: "var(--color-primary)" }}>
        QuickBite
      </strong>
      <span style={{ fontSize: "var(--font-small)" }}>Help · Account</span>
    </nav>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <TopNav />
      <Routes>
        <Route path="/" element={<Navigate to="/signup" replace />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/restaurants" element={<Restaurants />} />
        <Route path="/restaurants/:id" element={<RestaurantMenu />} />
        <Route path="/checkout" element={<Checkout />} />
        <Route path="/order-confirmation" element={<OrderConfirmation />} />
      </Routes>
    </BrowserRouter>
  );
}
