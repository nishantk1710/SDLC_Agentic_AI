// Thin fetch wrapper around the FastAPI backend. Base URL is configurable so
// the Testing Agent's E2E sandbox can point this at whatever port the
// backend container booted on (see runner/e2e_playwright.py in the plan).

const BASE_URL = process.env.REACT_APP_API_BASE_URL || "http://localhost:8000";

async function request(method, path, body) {
  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers: { "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const error = new Error(data.detail || "Request failed");
    error.status = res.status;
    error.body = data;
    throw error;
  }
  return data;
}

export const api = {
  register: (payload) => request("POST", "/api/auth/register", payload),
  login: (payload) => request("POST", "/api/auth/login", payload),
  listRestaurants: () => request("GET", "/api/restaurants"),
  getRestaurant: (id) => request("GET", `/api/restaurants/${id}`),
  addToCart: (payload) => request("POST", "/api/cart/items", payload),
  checkout: (payload) => request("POST", "/api/checkout", payload),
  confirmOrder: (payload) => request("POST", "/api/orders/confirm", payload),
};
