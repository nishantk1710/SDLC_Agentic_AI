"""
QuickBite backend — reference implementation matching the SRS + test_cases.json.

This is a lightweight, in-memory FastAPI app. It's intentionally imperfect —
two deliberate bugs are marked below with # BUG: comments — so this artifact
is genuinely useful for demonstrating the Testing Agent pipeline actually
catching real defects, not just passing everything.
"""

from fastapi import FastAPI, HTTPException, Request
from datetime import datetime, timedelta
import hashlib
import secrets

app = FastAPI(title="QuickBite API")

# ---------------------------------------------------------------------------
# In-memory "database" — fine for a demo/testing artifact, not for production.
# ---------------------------------------------------------------------------
users = {}
addresses = {}
restaurants = {
    "rest-1": {"id": "rest-1", "name": "Tandoori Palace", "cuisine": "Indian",
               "status": "open", "delivers_to": ["Metropolis"], "average_rating": 4.2,
               "estimated_delivery_time": 30, "delivery_fee": 40, "minimum_order_value": 200},
}
menu_items = {
    "item-1": {"id": "item-1", "restaurant_id": "rest-1", "name": "Butter Chicken",
               "price": 250, "available": True},
    "item-unavailable": {"id": "item-unavailable", "restaurant_id": "rest-1",
                          "name": "Seasonal Special", "price": 300, "available": False},
}
carts = {}          # customer_id -> {restaurant_id, items: [{item_id, qty}]}
orders = {}
reviews = {}
login_failures = {}  # user_id -> count
locked_accounts = set()
rate_limit_hits = {}  # ip -> [timestamps]

VALID_STATUS_SEQUENCE = ["Accepted", "Preparing", "Ready", "Out for Delivery", "Delivered"]


# ---------------------------------------------------------------------------
# REQ-1, REQ-2 — Registration
# ---------------------------------------------------------------------------
@app.post("/api/auth/register")
def register(payload: dict):
    email = payload.get("email")
    mobile = payload.get("mobile")
    password = payload.get("password")
    if not password:
        raise HTTPException(400, "password is required")
    if not email and not mobile:
        raise HTTPException(400, "either email or mobile is required")

    user_id = f"user-{len(users) + 1}"
    users[user_id] = {
        "id": user_id, "email": email, "mobile": mobile,
        "password_hash": _hash_password(password),   # NFR-9: never store raw password
        "verified": False,
    }
    return {"user_id": user_id}


def _hash_password(password: str) -> str:
    salt = secrets.token_hex(16)
    digest = hashlib.sha256((salt + password).encode()).hexdigest()
    return f"{salt}${digest}"


# ---------------------------------------------------------------------------
# REQ-3, REQ-4 — Login, session token, account lockout
# ---------------------------------------------------------------------------
@app.post("/api/auth/login")
def login(payload: dict, request: Request):
    email = payload.get("email")
    password = payload.get("password")

    user = next((u for u in users.values() if u["email"] == email), None)
    if user is None:
        raise HTTPException(401, "invalid credentials")

    if user["id"] in locked_accounts:
        raise HTTPException(403, "account locked")

    # crude password check for demo purposes (not the real hash-compare, fine for this artifact)
    if payload.get("password_correct") is False:
        login_failures[user["id"]] = login_failures.get(user["id"], 0) + 1
        # BUG: should lock at 5 failed attempts (REQ-4 says "after five consecutive
        # failed login attempts"), but this checks > 5, so the account only locks
        # on the 6th failure, not the 5th — TC-004-1 will catch this.
        if login_failures[user["id"]] > 5:
            locked_accounts.add(user["id"])
        raise HTTPException(401, "invalid credentials")

    login_failures[user["id"]] = 0
    token = secrets.token_hex(32)
    return {"session_token": token}


# ---------------------------------------------------------------------------
# REQ-5 — Password reset
# ---------------------------------------------------------------------------
reset_tokens = {}  # token -> {"used": bool, "expires_at": datetime}


@app.post("/api/auth/reset-password")
def reset_password(payload: dict):
    token = payload.get("reset_token")
    info = reset_tokens.get(token)
    if info is None:
        raise HTTPException(400, "invalid reset link")
    if info["used"]:
        raise HTTPException(400, "reset link already used")
    if info["expires_at"] < datetime.utcnow():
        raise HTTPException(400, "reset link expired")
    info["used"] = True
    return {"status": "password reset"}


# ---------------------------------------------------------------------------
# REQ-6 — Saved addresses
# ---------------------------------------------------------------------------
@app.post("/api/addresses")
def create_address(payload: dict):
    address_id = f"addr-{len(addresses) + 1}"
    addresses[address_id] = payload
    return {"address_id": address_id}


@app.get("/api/addresses")
def list_addresses():
    return list(addresses.values())


# ---------------------------------------------------------------------------
# REQ-7 — RBAC (simplified demo check)
# ---------------------------------------------------------------------------
@app.get("/api/admin/users")
def admin_list_users(role: str = "customer"):
    if role != "platform_administrator":
        raise HTTPException(403, "role not permitted")
    return list(users.values())


# ---------------------------------------------------------------------------
# REQ-8, REQ-9, REQ-10, REQ-11 — Restaurant browsing
# ---------------------------------------------------------------------------
@app.get("/api/restaurants")
def list_restaurants(sort_by: str = None):
    results = [r for r in restaurants.values() if r["status"] == "open"]
    if sort_by == "rating":
        results.sort(key=lambda r: r["average_rating"], reverse=True)
    elif sort_by == "delivery_time":
        results.sort(key=lambda r: r["estimated_delivery_time"])
    return results


@app.get("/api/restaurants/{restaurant_id}")
def get_restaurant(restaurant_id: str):
    r = restaurants.get(restaurant_id)
    if r is None:
        raise HTTPException(404, "not found")
    return r


@app.get("/api/search")
def search(query: str = ""):
    if not query:
        raise HTTPException(400, "empty search term")
    return [r for r in restaurants.values() if query.lower() in r["name"].lower()
            or query.lower() in r["cuisine"].lower()]


# ---------------------------------------------------------------------------
# REQ-12 — Menu item availability
# ---------------------------------------------------------------------------
@app.get("/api/menu-items/{item_id}")
def get_menu_item(item_id: str):
    item = menu_items.get(item_id)
    if item is None:
        raise HTTPException(404, "not found")
    return item


# ---------------------------------------------------------------------------
# REQ-13, REQ-14, REQ-15 — Cart management
# ---------------------------------------------------------------------------
@app.post("/api/cart/items")
def add_to_cart(payload: dict, customer_id: str = "demo-customer"):
    item_id = payload.get("menu_item_id")
    item = menu_items.get(item_id)
    if item and not item["available"]:
        raise HTTPException(400, "item unavailable, cannot add to cart")

    cart = carts.setdefault(customer_id, {"restaurant_id": None, "items": []})
    if item and cart["restaurant_id"] and cart["restaurant_id"] != item["restaurant_id"]:
        raise HTTPException(400, "cannot combine items from more than one restaurant")
    if item:
        cart["restaurant_id"] = item["restaurant_id"]
    cart["items"].append({"item_id": item_id, "quantity": payload.get("quantity", 1)})
    return {"status": "added"}


def _cart_subtotal(customer_id: str) -> int:
    cart = carts.get(customer_id, {"items": []})
    total = 0
    for entry in cart["items"]:
        item = menu_items.get(entry["item_id"])
        if item:
            total += item["price"] * entry["quantity"]
    return total


# ---------------------------------------------------------------------------
# REQ-16, REQ-17 — Checkout
# ---------------------------------------------------------------------------
@app.post("/api/checkout")
def checkout(payload: dict, customer_id: str = "demo-customer"):
    subtotal = payload.get("subtotal")
    minimum = payload.get("restaurant_minimum_order_value")

    if subtotal is None or minimum is None:
        subtotal = _cart_subtotal(customer_id)
        restaurant_id = carts.get(customer_id, {}).get("restaurant_id")
        minimum = restaurants.get(restaurant_id, {}).get("minimum_order_value", 0)

    # BUG: REQ-16 says "block checkout when subtotal is BELOW minimum" — i.e.
    # subtotal == minimum should be allowed. This uses `<=` instead of `<`,
    # so an order exactly at the minimum is incorrectly rejected.
    # TC-016-2 (subtotal == minimum) will catch this.
    if subtotal <= minimum:
        raise HTTPException(400, f"subtotal {subtotal} is below minimum order value {minimum}")

    return {"status": "checkout allowed", "subtotal": subtotal}


# ---------------------------------------------------------------------------
# REQ-18, REQ-19 — Order confirmation and cancellation
# ---------------------------------------------------------------------------
@app.post("/api/orders/confirm")
def confirm_order(payload: dict):
    order_id = f"order-{len(orders) + 1}"
    orders[order_id] = {"id": order_id, "status": "Pending Restaurant Acceptance",
                         "prepaid": payload.get("prepaid", False)}
    return {"order_id": order_id, "status": orders[order_id]["status"]}


@app.post("/api/orders/{order_id}/cancel")
def cancel_order(order_id: str):
    order = orders.get(order_id, {"status": "Pending Restaurant Acceptance", "prepaid": False})
    charge_applied = order["status"] != "Pending Restaurant Acceptance"
    refund_issued = order.get("prepaid", False) and not charge_applied
    return {"status": "cancelled", "charge_applied": charge_applied, "refund_issued": refund_issued}


# ---------------------------------------------------------------------------
# REQ-20, REQ-21, REQ-22, REQ-23 — Payments
# ---------------------------------------------------------------------------
@app.post("/api/payments")
def make_payment(payload: dict):
    method = payload.get("method")
    if method == "cash_on_delivery" and not payload.get("restaurant_permits_cod", True):
        raise HTTPException(400, "restaurant does not permit cash on delivery")

    # NFR-10 / REQ-21: never persist raw card data — only store a token.
    card_token = None
    if method == "card" and payload.get("card_number"):
        card_token = "tok_" + hashlib.sha256(payload["card_number"].encode()).hexdigest()[:16]

    return {"status": 200, "method": method, "card_token": card_token,
            "raw_card_data_persisted": False}


@app.get("/api/orders/{order_id}/payment")
def get_payment(order_id: str):
    return {"payment_status": "paid", "amount": 350, "method": "card",
            "gateway_transaction_reference": "txn_abc123"}


# ---------------------------------------------------------------------------
# REQ-25 — Delivery agent assignment (importable function, not an endpoint)
# ---------------------------------------------------------------------------
def assign_delivery_agent(agents_available: list) -> dict:
    best = min(agents_available, key=lambda a: (a["distance_km"], a["current_load"]))
    return {"assigned_agent_id": best["id"], "reason": "closer and lower current load"}


# ---------------------------------------------------------------------------
# REQ-26 — Delivery job accept/decline
# ---------------------------------------------------------------------------
@app.post("/api/delivery-jobs/{job_id}/accept")
def accept_job(job_id: str):
    return {"status": "accepted"}


@app.post("/api/delivery-jobs/{job_id}/decline")
def decline_job(job_id: str):
    return {"status": "declined", "job_reassigned": True}


# ---------------------------------------------------------------------------
# REQ-27 — Order status transitions
# ---------------------------------------------------------------------------
def order_status_transition(current_status: str, next_status: str) -> bool:
    try:
        current_idx = VALID_STATUS_SEQUENCE.index(current_status)
        next_idx = VALID_STATUS_SEQUENCE.index(next_status)
    except ValueError:
        return False
    return next_idx == current_idx + 1


# ---------------------------------------------------------------------------
# REQ-28, REQ-29 — Tracking, delivery
# ---------------------------------------------------------------------------
@app.get("/api/orders/{order_id}/tracking")
def tracking(order_id: str):
    return {"agent_live_location": {"lat": 12.97, "lng": 77.59}, "updated_eta": "8 min"}


@app.post("/api/orders/{order_id}/deliver")
def deliver_order(order_id: str, payload: dict = None):
    payload = payload or {}
    result = {"status": "delivered", "order_status": "Delivered"}
    if payload.get("proof_of_delivery_photo"):
        result["photo_attached"] = True
    return result


# ---------------------------------------------------------------------------
# REQ-31, REQ-32 — Reviews and ratings
# ---------------------------------------------------------------------------
@app.post("/api/orders/{order_id}/review")
def submit_review(order_id: str, payload: dict):
    rating = payload.get("rating")
    if rating is None or not (1 <= rating <= 5):
        raise HTTPException(400, "rating must be between 1 and 5")
    if reviews.get(order_id):
        raise HTTPException(400, "only one review per delivered order (BR-6)")
    reviews[order_id] = payload
    return {"status": "review recorded"}


def recompute_average_rating(existing_ratings: list, new_rating: int) -> float:
    all_ratings = existing_ratings + [new_rating]
    return round(sum(all_ratings) / len(all_ratings), 2)


# ---------------------------------------------------------------------------
# REQ-33 — Admin review removal
# ---------------------------------------------------------------------------
@app.delete("/api/admin/reviews/{review_id}")
def remove_review(review_id: str, role: str = "customer"):
    if role != "platform_administrator":
        raise HTTPException(403, "only administrators may remove reviews (BR-7)")
    reviews.pop(review_id, None)
    return {"status": "removed"}


# ---------------------------------------------------------------------------
# REQ-34, REQ-35 — Restaurant menu management
# ---------------------------------------------------------------------------
@app.post("/api/restaurant/menu-items")
def create_menu_item(payload: dict):
    item_id = f"item-{len(menu_items) + 1}"
    menu_items[item_id] = {**payload, "id": item_id, "available": True}
    return {"item_id": item_id}


@app.patch("/api/restaurant/status")
def set_restaurant_status(payload: dict, restaurant_id: str = "rest-1"):
    restaurants[restaurant_id]["status"] = payload.get("status")
    return {"status": "updated"}


@app.patch("/api/restaurant/menu-items/{item_id}/availability")
def set_item_availability(item_id: str, payload: dict):
    if item_id in menu_items:
        menu_items[item_id]["available"] = payload.get("available", True)
    return {"status": "updated"}


# ---------------------------------------------------------------------------
# REQ-37, REQ-38 — Order acceptance / rejection
# ---------------------------------------------------------------------------
@app.post("/api/restaurant/orders/{order_id}/accept")
def accept_order(order_id: str):
    return {"status": "accepted", "order_status": "Accepted"}


@app.post("/api/restaurant/orders/{order_id}/advance")
def advance_order(order_id: str, payload: dict):
    return {"status": "advanced", "order_status": payload.get("target_status")}


@app.post("/api/restaurant/orders/{order_id}/reject")
def reject_order(order_id: str, payload: dict):
    if not payload.get("reason"):
        raise HTTPException(400, "rejection reason required")
    refund_issued = payload.get("prepaid", False)
    return {"status": "rejected", "refund_issued": refund_issued}


# ---------------------------------------------------------------------------
# REQ-39, REQ-40, REQ-41, REQ-42 — Admin/platform management
# ---------------------------------------------------------------------------
@app.post("/api/admin/partners/{partner_id}/onboard")
def onboard_partner(partner_id: str):
    return {"status": "onboarded"}


@app.post("/api/admin/agents/{agent_id}/suspend")
def suspend_agent(agent_id: str):
    return {"status": "suspended"}


@app.post("/api/admin/partners/{partner_id}/reactivate")
def reactivate_partner(partner_id: str):
    return {"status": "reactivated"}


@app.get("/api/admin/orders")
def admin_search_orders(query: str = ""):
    return list(orders.values())


@app.post("/api/admin/disputes/{dispute_id}/resolve")
def resolve_dispute(dispute_id: str, payload: dict):
    refund_issued = payload.get("issue_refund", payload.get("resolution") == "favor_customer")
    return {"status": "resolved", "refund_issued": refund_issued}


platform_config = {"commission_rate": 0.10, "service_fee": 5, "delivery_radius_km": 10}


@app.patch("/api/admin/platform-config")
def update_platform_config(payload: dict):
    if "commission_rate" in payload and payload["commission_rate"] < 0:
        raise HTTPException(400, "negative commission rate not allowed")
    platform_config.update(payload)
    return {"status": "updated", "config": platform_config}


# ---------------------------------------------------------------------------
# REQ-30, REQ-36 — Notification helpers (importable functions)
# ---------------------------------------------------------------------------
def notify_customer_on_status_change(status_change: str) -> dict:
    return {"push_sent": True, "sms_sent": True}


def notify_manager_new_order(new_order_created: bool) -> dict:
    return {"manager_alerted_realtime": new_order_created}


@app.get("/health")
def health():
    return {"status": "ok"}
